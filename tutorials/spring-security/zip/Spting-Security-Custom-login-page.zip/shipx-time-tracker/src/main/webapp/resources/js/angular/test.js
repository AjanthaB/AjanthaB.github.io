/**
 * Created by dilanka on 12/10/15.
 */

var ttracker = angular.module('testapp',[]);

ttracker.controller("TestController" , function(){
    //you can edit this js file for making controllers

    this.msg = "this is a testing message of angular js";

});


